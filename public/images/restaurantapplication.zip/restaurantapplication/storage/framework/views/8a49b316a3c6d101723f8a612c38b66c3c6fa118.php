<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-4">
        <div class="list-group">
          <a href="/management/category" class="list-group-item list-group-item-action"><i class="fas fa-align-justify"></i> Category</a>
          <a class="list-group-item list-group-item-action"><i class="fas fa-hamburger"></i> Menu</a>
          <a class="list-group-item list-group-item-action"><i class="fas fa-chair"></i> Table</a>
          <a class="list-group-item list-group-item-action"><i class="fas fa-users-cog"></i> User</a>
        </div>
      </div>
      <div class="col-md-8">
        <i class="fas fa-align-justify"></i>Edit a Category
        <hr>
        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
        <?php endif; ?>
        <form action="/management/category/<?php echo e($category->id); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="form-group">
            <label for="categoryName">Category Name</label>
            <input type="text" name="name" value="<?php echo e($category->name); ?>"  class="form-control" placeholder="Category...">
          </div>
          <button type="submit" class="btn btn-primary">Update</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurantapplication\resources\views/management/editCategory.blade.php ENDPATH**/ ?>