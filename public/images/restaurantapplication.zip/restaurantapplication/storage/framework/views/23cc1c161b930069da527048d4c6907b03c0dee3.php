<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
      <?php echo $__env->make('management.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="col-md-8">
        <i class="fas fa-align-justify"></i>Category
        <a href="/management/category/create " class="btn btn-success btn-sm float-right"><i class="fas fa-plus"></i> Create Category</a>
        <hr>
        <?php if(Session()->has('status')): ?>
          <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">X</button>
            <?php echo e(Session()->get('status')); ?>

          </div>
        <?php endif; ?>
        <table class="table table-bordered">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Category</th>
              <th scope="col">Edit</th>
              <th scope="col">Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($category->id); ?></th>
                <td><?php echo e($category->name); ?></td>
                <td>
                  <a href="/management/category/<?php echo e($category->id); ?>/edit" class="btn btn-warning">Edit</a>
                </td>
                <td>
                <form action="/management/category/<?php echo e($category->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <input type="submit" value="Delete" class="btn btn-danger">
                </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php echo e($categories->links()); ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurantapp\resources\views/management/category.blade.php ENDPATH**/ ?>